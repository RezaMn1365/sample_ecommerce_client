import 'dart:async';
import 'dart:convert';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/network/server_requests.dart'
    as serverRequest;

class ActiveSessionPage extends StatefulWidget {
  Map activeSession = {};
  // ActiveSessionPage({Key? key, required this.activeSession}) : super(key: key)
  ActiveSessionPage({Key? key}) : super(key: key);

  @override
  _ActiveSessionPageState createState() => _ActiveSessionPageState();
}

class _ActiveSessionPageState extends State<ActiveSessionPage> {
  // Dummy Product Data Here
  List sessionList = [];
  bool terminat = false;
  bool loading = false;
  StreamController<List> loadController = StreamController<List>.broadcast();

  Future<void> startStreamData() async {
    print('start');
    // await Future<void>.delayed(const Duration(seconds: 2));

    var _response = await serverRequest.getActiveSessionAPI(context);
    if (_response['success'] == true) {
      List activeSessionList = _response['payload']['list'];
      sessionList = activeSessionList;
      loading = true;
      loadController.sink.add(activeSessionList);
      // loadController.close();
    } else {
      loading = false;
      setState(() {});

      // loadController.sink.addError('error');
      // await serverRequest.getActiveSessionAPI(context);
    }

    // loadController.close();
  }

  // final List sessionList = List.generate(100, (index) {
  //   return {"id": index, "title": "Product #$index", "price": index + 1};
  // });

  @override
  void initState() {
    // List activeSessionList = widget.activeSession['payload']['list'];
    // sessionList = activeSessionList;
    // _onceAfterBuild();
    startStreamData();

    // sessionList = List.generate(activeSessionList.length, (index) {
    //   return {
    //     "id": index,
    //     "session Id": "$activeSessionList['session_id']",
    //     "client": "$activeSessionList['client']['info']"
    //   };
    // });

    // TODO: implement initState
    super.initState();

    // Future.delayed(Duration.zero, () => _onceAfterBuild());
    // Stream stream = loadController.stream;
  }

  // void sendServerRequest() {}

  // void _onceAfterBuild() async {
  //   var _activeSession = await serverRequest.getActiveSessionAPI(context);
  //   if (_activeSession['success'] == true) {
  //     List activeSessionList = _activeSession['payload']['list'];
  //     sessionList = activeSessionList;
  //     loading = true;
  //     setState(() {});
  //     loadController.add(true);
  //   } else {
  //     Timer.periodic(Duration(seconds: 5), (Timer t) {
  //       if (loading == true) {
  //         t.cancel();
  //       }
  //       setState(
  //         () {
  //           _onceAfterBuild();
  //           print('refreshed');
  //           // _onceAfterBuild();
  //         },
  //       );
  //     });
  //     loading = false;
  //   }
  // }

  // void listener() {
  //   loadController.stream.listen((event) {}).onError((error) {
  //     print(error);
  //   });

  // setState(() {});
  // print(loading);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Active Session Managment'),
        // backgroundColor: Colors.red,
      ),
      body: RefreshIndicator(
        onRefresh: startStreamData,
        child: StreamBuilder(
          stream: loadController.stream,
          builder: (context, AsyncSnapshot snapshot) {
            // loadController.stream.listen((event) {}).onError((error) {
            //   // loadController.stream.listen((event) {}).pause();
            //   Future.delayed(const Duration(seconds: 5), () {
            //     // loadController.stream.listen((event) {}).resume();
            //     startStreamData();
            //   });

            //   // print(error);
            // });

            // loadController.stream.handleError((onError) {
            //   onError:
            //   () => Future.delayed(const Duration(seconds: 5), () {
            //         startStreamData();
            //       });
            // });

            if (!snapshot.hasData) {
              // loading = false;
              // print(snapshot.error);

              // print('no');
              return mainList();
            } else {
              switch (snapshot.connectionState) {
                case ConnectionState.none:
                case ConnectionState.waiting:
                  // loading = false;
                  // print('wai');
                  return mainList();

                case ConnectionState.active:
                case ConnectionState.done:
                  // loading = true;
                  // loadController.close();
                  return mainList();

                default:
                  // loading = false;
                  // print('def');
                  return mainList();
              }
            }
          },
        ),
      ),
    );
  }

  Widget mainList() {
    return ListView.builder(
      itemCount: loading ? sessionList.length : 1,
      itemBuilder: (BuildContext ctx, index) {
        // Display the list item
        return Dismissible(
            key: UniqueKey(),

            // only allows the user swipe from right to left
            direction: DismissDirection.endToStart,

            // Remove this product from the list
            // In production enviroment, you may want to send some request to delete it on server side
            onDismissed: (_) async {
              var _id = sessionList[index]['session_id'].toString();
              print(sessionList[index]['session_id'].toString());
              await _deletSessionApproveCancelDialog(index);
              if (terminat == true) {
                await serverRequest.terminateActiveSessionAPI(context, _id);
              }

              setState(() {
                // sessionList.removeAt(index);
              });
            },

            // Display item's title, price...
            child:
                // return
                Card(
              key: UniqueKey(),
              margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
              child: ListTile(
                leading: CircleAvatar(
                  // backgroundColor: Colors.red,
                  child: loading
                      ? Text(sessionList.length.toString())
                      : Icon(Icons.error),
                ),
                subtitle: loading
                    ? Text('session_id : ${sessionList[index]["session_id"]}')
                    : null,
                title: loading
                    ? Text(
                        "info: ${sessionList[index]["client"]['info'].toString()}")
                    : const Card(
                        // margin: EdgeInsets.all(35),
                        // shape: const Border(left: BorderSide(color: Colors.grey, width: 8)),
                        elevation: 10,
                        child: LinearProgressIndicator(
                          backgroundColor: Colors.grey,
                        ),
                      ),
                trailing: loading
                    ? IconButton(
                        onPressed: () async {
                          var _id = sessionList[index]['session_id'].toString();
                          print(sessionList[index]['session_id'].toString());
                          await _deletSessionApproveCancelDialog(index);
                          if (terminat == true) {
                            await serverRequest.terminateActiveSessionAPI(
                                context, _id);
                          }

                          setState(() {
                            // sessionList.removeAt(index);
                          });
                        },
                        icon: const Icon(Icons.delete),
                      )
                    : null,
              ),
            ));
      },
    );
  }

  Future<void> _deletSessionApproveCancelDialog(var index) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Terminate'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[
                // Text('Alert!'),
                Text('Are you sure to terminate this session?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Approve'),
              onPressed: () {
                sessionList.removeAt(index);
                terminat = true;
                Navigator.of(context).pop(context); //close dialog
              },
            ),
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                terminat = false;
                Navigator.of(context).pop(context); //close dialog
              },
            ),
          ],
        );
      },
    );
  }
}
