import 'package:flutter/material.dart';

import 'package:flutter_application_1/network/server_requests.dart'
    as serverRequest;
import 'package:flutter_application_1/network/server_requests.dart';

class LoginHistoryPage extends StatefulWidget {
  // Map loginHistory = {};
  int pageItems;
  int totalItems;
  int totalPages;
  LoginHistoryPage(
      {Key? key,
      required this.pageItems,
      required this.totalItems,
      required this.totalPages})
      : super(key: key);
  var items;
  @override
  State<LoginHistoryPage> createState() => _LoginHistoryPageState();
}

class _LoginHistoryPageState extends State<LoginHistoryPage> {
  List lst = [];
  // int pNum = 8;
  int page = 1;
  int size = 8;
  bool getCount = true;
  final ScrollController scrollController = ScrollController();

  @override
  void initState() {
    // activeSessionResponseData = await getProfileAPI();
    // print(widget.loginHistory);

    scrollController.addListener(() {
      if (scrollController.offset >=
              scrollController.position.maxScrollExtent &&
          lst.length < widget.totalItems) {
        print("reach the bottom");

        setState(() {
          page += 1;
          size = 8;
          getCount = false;
          // pNum = pNum + 8;
        });
      }
      if (scrollController.offset <=
          scrollController.position.minScrollExtent) {
        print("reach the top");
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.red,
        title: const Text('Active Session List'),
      ),
      body: Center(
        child: FutureBuilder(
          future: fetchDataList(),
          builder: (context, AsyncSnapshot snapshot) => Stack(
            children: [
              snapshot.hasData
                  ? Scrollbar(
                      thickness: 10,
                      child: ListView.builder(
                        // addAutomaticKeepAlives: true,
                        controller: scrollController,
                        itemCount: snapshot.data.length,
                        scrollDirection: Axis.vertical,
                        itemBuilder: (BuildContext context, int index) {
                          return Card(
                            shape: const Border(
                                left:
                                    BorderSide(color: Colors.grey, width: 10)),
                            elevation: 10,
                            child: ListTile(
                              tileColor: Colors.grey[100],
                              title: Text(
                                  '${snapshot.data[index]['client']['info']}'),
                              subtitle: Text('${snapshot.data[index]['time']}'),
                              leading: Text('${index + 1}'),
                            ),
                          );
                        },
                      ),
                    )
                  : Positioned(
                      bottom: 35,
                      left: MediaQuery.of(context).size.width * 0.45,
                      // height:
                      //     MediaQuery.of(context).size.height * 0.2,
                      child: const Align(
                          alignment: Alignment.topCenter,
                          child: CircularProgressIndicator()),
                    ),
              snapshot.connectionState == ConnectionState.active ||
                      snapshot.connectionState == ConnectionState.none ||
                      snapshot.connectionState == ConnectionState.waiting
                  ? Positioned(
                      bottom: 35,
                      left: MediaQuery.of(context).size.width * 0.45,
                      // height:
                      //     MediaQuery.of(context).size.height * 0.2,
                      child: const Align(
                          alignment: Alignment.topCenter,
                          child: CircularProgressIndicator()),
                    )
                  : const SizedBox(
                      width: 0,
                      height: 0,
                    ),
            ],
          ),
        ),
      ),

      //  ListView.builder(
      //   controller: scrollController,
      //   itemCount: widget.loginHistory['payload']['list'].length,
      //   itemBuilder: (context, index) {
      //     return ListTile(
      //       subtitle: Text(widget.loginHistory['payload']['list'][index]['client']['info']),
      //       title: Text(widget.loginHistory['payload']['list'][index]['time']),
      //     );
      //   },
      // ),
      // floatingActionButton: FloatingActionButton(onPressed: () async {
      //   widget.loginHistory = await serverRequest.getLoginHistoryAPI();
      //   lst = widget.loginHistory['payload']['list'];
      //   setState(() {});
      // }),
    );
  }

  Future<List> fetchDataList() async {
    var rawData = await getLoginHistoryAPI(page, size, getCount);
    if (page <= 1) {
      lst = (rawData['payload']['list']);
    } else {
      lst.addAll(rawData['payload']['list']);
      // lst = lst.toSet().toList(); //remove duplicate items from list
    }

    // print(lst.length);
    // print(lst);
    return lst;
  }
}
